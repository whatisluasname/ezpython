code = input("add some easy code! ")


if input: "poop"  # this is used as a placeholder for code.


f = open(r"C:\Users\Ezzy\PycharmProjects\EZPython\output.txt", "w")   # 'r' for reading and 'w' for writing
f.write(code)                            # Write inside file
f.close()                                # Close file

import webbrowser as wb
wb.get('chrome %s').open_new_tab('http://www.github.com')

# oh, and change the directory to the place you put EZPython in.
# also change the brp


# this code is somewhat improved..
# please contribute.